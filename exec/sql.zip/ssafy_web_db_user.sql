-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: localhost    Database: ssafy_web_db
-- ------------------------------------------------------
-- Server version	8.0.39-0ubuntu0.20.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `user_id` int NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `nickname` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `profile_picture` varchar(255) DEFAULT NULL,
  `level` int DEFAULT NULL,
  `user_identifier` varchar(255) DEFAULT NULL,
  `role` varchar(255) NOT NULL,
  `fcm` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `email_UNIQUE` (`email`),
  UNIQUE KEY `UKob8kqyqqgmefl0aco34akdtpe` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'minipeach0923@gmail.com','박민지[대전_2반_B202]','ming','01012345678','https://lh3.googleusercontent.com/a/ACg8ocKaj00jNdXXK5RdyU02_kl5ct9RhAF3W5DIpKZgn_XRuKr6rtY5=s96-c',8,'google 115861901847095529660','ROLE_USER','null'),(2,'alswl554@naver.com','박민지','용용','2345','https://lh3.googleusercontent.com/a/ACg8ocKaj00jNdXXK5RdyU02_kl5ct9RhAF3W5DIpKZgn_XRuKr6rtY5=s96-c',1,'google 1WQE60','ROLE_USER',NULL),(3,'skthddus1238@gmail.com','라송연','졸려','01012345678','https://i11b202.p.ssafy.io/openvidu/recordings/live/20240812/1280728772135945.png',1,'google 118356992271822981823','ROLE_USER',NULL),(4,'cadetblue@hanyang.ac.kr','­윤채영','monk','00000000000','https://lh3.googleusercontent.com/a/ACg8ocKN-AAlrk6QzYDn11QqzfBl_wc4dpzJRLIFdLmGanuxFYvy2g=s96-c',1,'google 108662866656861617171','ROLE_USER','cVaEOVd7dvwXoPgEHP8cZJ:APA91bHwpwQ03k9-bpzR3apD1dlRixMOqcVLQMt0-NvQ9npbhcEULEpvXL9YMX_ykLcXoXg8uD9ldUKU8lXh9HUEwTuiFeiFH_bAHG3KBI9mzOcHLTM8H5bmIaFh80mWuWwEzLHmXJoz'),(5,'rhdns208@gmail.com','[대전_2반_구고운]','초합금키티','010-1234-5678','https://i11b202.p.ssafy.io/openvidu/recordings/live/20240812/1329606778008305.png',1,'google 118402300158655394160','ROLE_USER','e6yG_2EjH_CMaTGpHKz8DX:APA91bEGw4VbGSP9G1VN36oiVAwADjn34WFC7GlOyBOXox-omNbvxrTS62z8KPSI7cgId4oIgm6VBG-wMgy7D8AnjWOXJu7xQsBqmVT-LPQ6vlIsnBjsSALT1pw_vAQXX0lpKW2hUNvR'),(6,'qsc753969@gmail.com','김용원[대전_2반_B202]','용원','568','https://lh3.googleusercontent.com/a/ACg8ocIm8M871xeqLslQlNUW-Ms2TUZmXvpux21cpNvxRFZiSZME-g=s96-c',6,'google 104704618556302111710','ROLE_USER','cYiVoBsyyaAfS1FxVpKFAR:APA91bHnQZ7Z4GZC8BcWLrJysPTsgbuZOx6x5Gy59osq3lZuVOHgq0nZoGzOSl9DzUkt395yEKTE32QXlRrPheWkGB0xCm_pNRVZgSrzqT4E2tdGOkfWeYioRovCCJu8DS75UlQ1bRNV'),(7,'qwsa522@naver.com','김용원','용원','6789','http://t1.kakaocdn.net/account_images/default_profile.jpeg.twg.thumb.R640x640',0,'kakao 3643608242','ROLE_USER','cBk_xwoIRilIUejd3xvjJX:APA91bFqpK1UWvGnZpkhwoE0rikzwiG-xgcgknQk9wVNu269eUsNgrSwJG295ALRCTcTI7hKFtD9MzPKJcBOyVdf3YT_MNRPCNwsxxl46X7IDmxiT3cigaXG2W56TmipXwwo7s_EBLOF'),(8,'snnsprng3@gmail.com','이니','딸기왕 초호기','010-9876-5432','https://lh3.googleusercontent.com/a/ACg8ocLuYKfKZi4XiAaZVTdKlXCaeG_Wq3eg2G_7aBOchYdRXvzmGes=s96-c',8,'google 107944639069350552494','ROLE_USER','null'),(9,'gimain94@gmail.com','cg cg','해이니','809-','https://lh3.googleusercontent.com/a/ACg8ocKozsyyVpgcTa4ObBGB0YOer_yODqrEPISFHs4kDZSnFWS7GsI=s96-c',2,'google 114544971782455136284','ROLE_USER',NULL),(10,'simin4300@daum.net','이주혁','test',NULL,'http://t1.kakaocdn.net/account_images/default_profile.jpeg.twg.thumb.R640x640',0,'kakao 3657318172','ROLE_USER','null'),(11,'xoals3377@naver.com','태민','aaaa','[object Undefined]','http://t1.kakaocdn.net/account_images/default_profile.jpeg.twg.thumb.R640x640',0,'kakao 3657412680','ROLE_USER',NULL),(14,'b9s2w6@ajou.ac.kr','백성욱',NULL,NULL,'https://lh3.googleusercontent.com/a/ACg8ocIhThGXzB8mNePn4tAblWSt2rPZpWbNJ4Cv8sv1j5KUfA5kdQ=s96-c',0,'google 101032080610981779097','ROLE_USER','dC79qErLxJRvzrOFHG1jEB:APA91bFSYttgybCcc4VOrGNXwn2ztYwNSpwgA_EWJ7JZsmG3W-4spyJxsB05eBDwnFaIETqlP8InM68D-a-W7MOYc0xSIhg-vUFhP1zJ5T6X_WyZgnxC_p2F4RzXKWHOwduSk4vTD3mj'),(15,'ykjeong.ssafy@gmail.com','정용기 (컨설턴트)',NULL,NULL,'https://lh3.googleusercontent.com/a/ACg8ocIsCKJehR_X-JkgHOE0ZpEicNMEqcuo12TThtPs6dUR9JMvKuGa=s96-c',0,'google 113043074187121676724','ROLE_USER','eRvQXJR_RxjebMeTwTrlau:APA91bG09-qspNeMkhEIsYyCIXnl4AItmPNPccsHVhP1v7_mNB4EF_8bon-8kHPnKP7OgbO5pKIGyga0itsZpSwa0zCllITADSjR6JRar9hlIDJ5ZBnrgZYPFSNq5rWpJ6JbP_iGtOpG'),(16,'leesumin305@gmail.com','이수민',NULL,NULL,'http://t1.kakaocdn.net/account_images/default_profile.jpeg.twg.thumb.R640x640',0,'kakao 3663986575','ROLE_USER','null'),(17,'cadetblue49@gmail.com','윤채영',NULL,NULL,'http://k.kakaocdn.net/dn/bYbHmd/btszzCynqWr/neGt08bVJeSc5RX2DrSEwK/img_640x640.jpg',0,'kakao 3641899814','ROLE_USER','null'),(19,'skthddus123@naver.com','라송연',NULL,NULL,'https://ssl.pstatic.net/static/pwe/address/img_profile.png',0,'naver iaFl78Ckw1ipeHJ_KrE_yMxph7pd6RCXzkikXrdmKT4','ROLE_USER','null');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-08-16  7:37:06
